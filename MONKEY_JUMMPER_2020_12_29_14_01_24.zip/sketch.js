//var PLAY = 1;
//var END = 0;
//var gameState = PLAY;



var banana,banana_image,obstacle,obstacle_image;
var BananaGroup,ObstacleGroup;
var player,player_running;
var score;
var ground,ground_image,invisibleGround;

function preload(){
  banana_image= loadImage("banana.png");
  obstacle_image= loadImage("stone.png");
  ground_image = loadImage("jungle.jpg");
  
  player_running=loadAnimation("Monkey_01.png",
                               "Monkey_02.png",
"Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png",
"Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
} 





function setup() {
  createCanvas(800,400);
  
  ground = createSprite(0,0,800,400);
  ground.addImage(ground_image);
  ground.x = ground.width /2;
  ground.velocityX = -2;
  ground.scale=1.5;
 
  player = createSprite(100,340,20,50);
  player.addAnimation("running", player_running);
  player.scale = 0.15;
   
  invisibleGround=createSprite(400,350,800,10)
  invisibleGround.vvelocityX=-2;
   invisibleGround.x = invisibleGround.width /2;
  invisibleGround.visible=false;
  
score=0;
   
  BananaGroup = new Group();
  ObstacleGroup = new Group();
}

function draw() {
  background(220);
  //play
 
    //Moving ground
     ground.velocityX = -(6 + 3*score/100);
   if(ground.x<100)
 {  ground.x = ground.width /2;
    } 
    //Moving invisible ground
 if(invisibleGround.x<100)
 {  invisibleGround.x = invisibleGround.width /2;
    } 
    //Scoring
    score = score + Math.round(getFrameRate()/60);
   //Giving velocity and colliding PLAYER with invisibleGround
   if(keyDown("space") ) {
      player.velocityY = -12;
    }
  player.velocityY = player.velocityY + 0.8
  player.collide(invisibleGround);
 
  
   if(ObstacleGroup.isTouching(player)){
    player.scale=player.scale- 0.2;
     ObstacleGroup.destroyEach();
    }
  Banana();
  Obstacle();
    
 if(BananaGroup.isTouching(player)){
   BananaGroup.destroyEach();
   player.scale=player.scale+0.15;
     
    }   
 // switch(score){
     // case 10:player.scale=0.12;
      // break;
      // case 40:player.scale=0.12;
      // break;
      // case 60:player.scale=0.14;
      // break;
      
      // default:break;
      // }
  
  
  drawSprites();
  stroke("white");
  textSize(20);
  fill("white");
  text("Score ="+" "+ score,500,50);
} 

function Banana() {
if (frameCount%300===0) {
var banana = createSprite(600,250,20,20);
   banana.y = Math.round(random(100,200));
  banana.addImage(banana_image);
banana.scale=0.05;
banana.velocityX=-1 ;
BananaGroup.add(banana);
banana.lifetime=300;
}
} 

function Obstacle() {
 if(frameCount % 100 === 0) { 
    var obstacle = createSprite(800,350,10,40);
   obstacle.velocityX = -(2+score/50) ;
    //obstacle.y = Math.round(random(800,350));
    
    //generate random obstacles
    obstacle.addImage(obstacle_image);
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.15;
    obstacle.lifetime = 300;
    //add each obstacle to the group
    ObstacleGroup.add(obstacle);
  } 
}

